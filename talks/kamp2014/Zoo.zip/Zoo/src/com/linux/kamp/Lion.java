package com.linux.kamp;

public class Lion extends Animal {

	public Lion(String name, int age) {
		super(name, age);
	}

	@Override
	public void walk() {
		System.out.println("Lion walks");
	}

	@Override
	public void eat() {
		System.out.println("Lion eats");
	}

}
