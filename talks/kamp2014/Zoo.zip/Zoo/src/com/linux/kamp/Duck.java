package com.linux.kamp;

public class Duck extends Animal {

	public Duck(String name, int age) {
		super(name, age);
	}

	@Override
	public void walk() {
		System.out.println("Duck-walk");
	}

	@Override
	public void eat() {
		System.out.println("Duck eats");
		
	}

}
