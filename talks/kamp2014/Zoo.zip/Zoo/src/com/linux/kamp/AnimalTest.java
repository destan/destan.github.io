package com.linux.kamp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AnimalTest {

	public static void main(String[] args) {
		List<Animal> duckCage = new ArrayList<Animal>();
		Duck duck1 = new Duck("Duffy", 1);
		duckCage.add(duck1);
		
		List<Animal> lionCage = new ArrayList<Animal>();
		Lion lion1 = new Lion("King", 2);
		lionCage.add(lion1);

		List<Animal> parrotCage = new ArrayList<Animal>();
		Parrot parrot1 = new Parrot("Cafer", 5);
		parrotCage.add(parrot1);
		

		List<List<Animal>> zoo = new ArrayList<List<Animal>>();
		
		zoo.add(duckCage);
		zoo.add(lionCage);
		zoo.add(parrotCage);
		
		Print<List<Animal>> printer = new Print<List<Animal>>();
		printer.print(duckCage);
		
		printAll(zoo);
		
	}

	private static void printAll(Collection<List<Animal>> collection) {
		for (List<Animal> animalList : collection) {
			for (Animal animal : animalList) {
				System.out.println(animal);
			}
		}

	}
}

















