package com.linux.kamp;

public class Parrot extends Animal implements Speakable {

	public Parrot(String name, int age) {
		super(name, age);
	}

	@Override
	public void speak() {
		System.out.println("Babacim");

	}

	@Override
	public void walk() {
		System.out.println("Parrot-walk");

	}

	@Override
	public void makeNoise() {
		speak();
	}

	@Override
	public void eat() {
		System.out.println("Parrot eats");
		
	}

}
