package com.linux.kamp;

import java.util.Collection;
import java.util.Iterator;

public class Print <T extends Collection<Animal>>{

	public void print(T collection){
		for (Animal animal : collection) {
			System.out.println(animal);
		}
	}
	
	public void printUsingIterator(T collection){
		
		for (Iterator<Animal> iterator = collection.iterator(); iterator.hasNext();) {
			Animal animal =  iterator.next();
			System.out.println(animal);
		}
	}
}
