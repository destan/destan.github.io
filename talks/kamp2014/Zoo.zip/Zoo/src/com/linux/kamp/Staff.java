package com.linux.kamp;

public class Staff<T extends Animal> {

	private String name;

	public void feed(T animal) {
		System.out.println("Staff feeds animal");
		animal.eat();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
