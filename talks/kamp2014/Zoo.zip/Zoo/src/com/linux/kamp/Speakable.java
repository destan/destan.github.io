package com.linux.kamp;

public interface Speakable extends Noisy {

	public void speak();
}
