package com.linux.kamp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PlaygroundListToMap {
	public static void main(String[] args) {
		List<Animal> animals = new ArrayList<Animal>();

		animals.add(new Lion("King I", 3));
		animals.add(new Lion("King II", 2));
		animals.add(new Lion("King III", 1));

		animals.add(new Duck("Duffy I", 3));
		animals.add(new Duck("Duffy II", 2));
		animals.add(new Duck("Duffy III", 1));

		animals.add(new Parrot("Cafer I", 3));
		animals.add(new Parrot("Cafer II", 2));
		animals.add(new Parrot("Cafer III", 1));

		/**
		 * To sort List<Animal>, Animal class MUST 
		 * implement Comparable interface
		 */
		Collections.sort(animals);

		for (Animal animal : animals) {
			System.out.println(animal);
		}

	}
}
