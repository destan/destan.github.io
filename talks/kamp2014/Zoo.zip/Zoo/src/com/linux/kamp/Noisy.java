package com.linux.kamp;

public interface Noisy {
	
	public void makeNoise();
}
