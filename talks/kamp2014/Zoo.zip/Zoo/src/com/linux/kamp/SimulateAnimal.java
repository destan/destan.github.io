package com.linux.kamp;

public class SimulateAnimal {

	private static SimulateAnimal instance;

	private String name;

	private SimulateAnimal() {
		// TODO Auto-generated constructor stub
	}

	public static SimulateAnimal getInstance() {
		// Lazy initialization

		if (instance == null) {
			instance = new SimulateAnimal();
		}

		return instance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
