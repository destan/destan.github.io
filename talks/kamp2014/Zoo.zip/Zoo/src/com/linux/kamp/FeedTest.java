package com.linux.kamp;

public class FeedTest {
	public static void main(String[] args) {
		Duck duck1 = new Duck("Duffy", 1);
		Lion lion1 = new Lion("King", 2);
		
		Staff<Duck> duckKeeper = new Staff<Duck>();
		Staff<Lion> lionKeeper = new Staff<Lion>();
		Staff<Animal> generalKeeper = new Staff<Animal>();
		
		duckKeeper.feed(duck1);
		lionKeeper.feed(lion1);
		
		generalKeeper.feed(duck1);
		generalKeeper.feed(lion1);
	}
}
